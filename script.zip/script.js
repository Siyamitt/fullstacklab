const express = require("express");
const app = express();

app.use(express.json());

// simple storage
let users = [];

// ------------------ MIDDLEWARE ------------------
app.use((req, res, next) => {
    let time = new Date().toLocaleString();
    console.log("Request received at:", time);
    console.log(req.method, req.url);
    next();
});

app.get("/", (req, res) => {
    res.json({
        message: "Server Running",
        time: new Date().toLocaleString()
    });
});

app.get("/users", (req, res) => {
    res.json({
        message: "All users fetched",
        data: users,
        time: new Date().toLocaleString()
    });
});

app.get("/users", (req, res) => {
    console.log("Users route working");

    res.json({
        message: "All users fetched",
        data: users,
        time: new Date().toLocaleString()
    });
});

    let found = users.find(u => u.email === email);
    if (found) {
        return res.json({
            message: "Email already exists",
            time: new Date().toLocaleString()
        });
    }

    let newUser = {
        id: users.length + 1,
        name: name,
        email: email
    };

    users.push(newUser);

    res.json({
        message: "User added",
        data: newUser,
        time: new Date().toLocaleString()
    });
});



    users.splice(index, 1);

    res.json({
        message: "User deleted",
        time: new Date().toLocaleString()
    });
});




app.listen(3000, () => {
    console.log("Server started on port 3000");
});